function f = eye_1(x1)
% f = feature vector
% x1 = the input signal

f1 = mean (x1); %mean eye_blink
f2 = std (x1); %Standard deviation eye_blink
f3 = median (x1); %Median eye_blink
f4 = mode (x1); % mode eye_blink
f5 = max (x1); % Largest elements in eye_blink
f6 = min (x1); % Smallest elements in eye_blink
f7 = skewness (x1); %Skewness eye_blink
f8 = kurtosis (x1); %Kurtosis eye_blink
f9 = var (x1); %variance eye_blink
d1 = diff(x1);  % the differences between the elements (1st derivative)of eye_blink
f10 = mean (d1); % Arithmetic average of the first derivative of the eye_blink
f11 = max (d1); % Maximum value of the first derivative of the eye_blink
f12 = rms (x1); % Root mean square (RMS) eye_blink
f13 = fr_analy(x1); % the frequency measures, including area under PSD, Max.Power, SEF50,SEF95 
f17 = Higuchi_FD(x1, 3); % the Higuchi Fractal

f = [f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11,f12,f13,f17];