function feat=fr_analy(y)

Fs = 30;                    % Sampling frequency
T = 1/Fs;                     % Sample time
L = length(y);                     % Length of signal
t = (0:L-1)*T;                % Time vector
NFFT = 2^nextpow2(L); % Next power of 2 from length of y
Y = fft(y,NFFT)/L;
f = Fs/2*linspace(0,1,NFFT/2+1);
Sp_y = 2*abs(Y(1:NFFT/2+1));% single-sided amplitude spectrum

[pmax, r]=max(Sp_y);% Max.Power and its corresponding frequency
fmax = f(r);
area_1 = sum(Sp_y); % The area under the power
J = 0.5*area_1; 
SEF=0; i = 1;
while SEF < J
     SEF = Sp_y(i)+ SEF;
     i = i+1;
end
    f_50 = f(i);
    J = 0.95*area_1; 
SEF=0; i = 1;
while SEF < J
     SEF = Sp_y(i)+ SEF;
     i = i+1;
end
    f_95 = f(i);
    
    % The 95% spectral edge frequency

feat=[area_1,pmax,f_50,f_95];


